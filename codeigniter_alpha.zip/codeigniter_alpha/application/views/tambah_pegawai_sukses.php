<?php 

	echo "Sukses Simpan Data";

	echo anchor('pegawai/create', 'Masukkan Data Lagi');
 ?>