<?php 
//redirect('pegawai','refresh');
echo '<script language="javascript">';
echo 'alert("Data Berhasil Dihapus")';
echo '</script>';
 ?>

 <?php 
redirect('pegawai','refresh');
 ?>